package model;

/**
 * Rabbit class representing a rabbit pet.
 */
public class Rabbit extends Pet {
    public Rabbit(String id, String name, int age, String species) {
        super(id, name, age, species);
    }
}