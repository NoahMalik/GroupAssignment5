package model;

/**
 * Cat class representing a cat pet.
 */
public class Cat extends Pet {
    public Cat(String id, String name, int age, String species) {
        super(id, name, age, species);
    }
}