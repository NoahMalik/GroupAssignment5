package model;

/**
 * Dog class representing a dog pet.
 */
public class Dog extends Pet {
    public Dog(String id, String name, int age, String species) {
        super(id, name, age, species);
    }
}