/**
 * 
 */
/**
 * 
 */
module GroupAssignment5 {
	requires java.desktop;
	requires gson;
}